#!/usr/bin/env python

import numpy as np
import pandas as pd

relata_fields = """
relatum tags frequency term-dominatPOS distPOS distForms distPosMorph
""".strip().split()

relation_fields = """
left relation right tags sentence
voteStrongDis voteDis voteNeu voteAgr voteStrongAgr
kappa numVote voteAvg voteVar voteAvgMinusVar source sourceScore
""".strip().split()

relata = pd.read_table("RELATA.txt", names=relata_fields, header=None)
relations = pd.read_table("RELATIONS.txt", names=relation_fields, header=None)




